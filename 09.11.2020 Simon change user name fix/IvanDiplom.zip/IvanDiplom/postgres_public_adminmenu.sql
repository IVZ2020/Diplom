INSERT INTO public.adminmenu (id, menulink, menurus) VALUES (2, 'getAllUsers', 'Вывести список юзеров');
INSERT INTO public.adminmenu (id, menulink, menurus) VALUES (4, 'help', 'Помощь');
INSERT INTO public.adminmenu (id, menulink, menurus) VALUES (3, 'messages', 'Сообщения');
INSERT INTO public.adminmenu (id, menulink, menurus) VALUES (5, 'mainPage', 'На главную');
INSERT INTO public.adminmenu (id, menulink, menurus) VALUES (9, 'logoutServlet', 'Выход');
INSERT INTO public.adminmenu (id, menulink, menurus) VALUES (1, 'editAdminProfile', 'Изменить свои данные');