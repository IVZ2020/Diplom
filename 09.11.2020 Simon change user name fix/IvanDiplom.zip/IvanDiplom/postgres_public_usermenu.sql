INSERT INTO public.usermenu (id, menulink, menurus) VALUES (4, 'history', 'История операций');
INSERT INTO public.usermenu (id, menulink, menurus) VALUES (5, 'calc', 'Калькулятор');
INSERT INTO public.usermenu (id, menulink, menurus) VALUES (6, 'messages', 'Сообщения');
INSERT INTO public.usermenu (id, menulink, menurus) VALUES (7, 'mainPage', 'На главную');
INSERT INTO public.usermenu (id, menulink, menurus) VALUES (8, 'logoutServlet', 'Выход');
INSERT INTO public.usermenu (id, menulink, menurus) VALUES (1, 'changeUserName', 'Изменить свои данные');