create table userfields
(
);

alter table userfields owner to postgres;

