INSERT INTO public.messages (id, messagerus, messageeng) VALUES (1, 'Авторизация', 'Authorization');
INSERT INTO public.messages (id, messagerus, messageeng) VALUES (3, 'Неверный логин', 'Wrong login');
INSERT INTO public.messages (id, messagerus, messageeng) VALUES (4, 'Нверный пароль', 'Wrong password');