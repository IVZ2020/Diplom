INSERT INTO public.mainmenu (id, menulink, menurus) VALUES (5, 'reg', 'Регистрация');
INSERT INTO public.mainmenu (id, menulink, menurus) VALUES (8, 'help', 'Помощь');
INSERT INTO public.mainmenu (id, menulink, menurus) VALUES (6, 'auth', 'Личный кабинет');
INSERT INTO public.mainmenu (id, menulink, menurus) VALUES (9, 'logoutServlet', 'Выход');