INSERT INTO public.adminfields (id, fieldlink, fieldrus) VALUES (10, 'name', 'Имя');
INSERT INTO public.adminfields (id, fieldlink, fieldrus) VALUES (11, 'lastName', 'Фамилия');
INSERT INTO public.adminfields (id, fieldlink, fieldrus) VALUES (12, 'login', 'Логин');
INSERT INTO public.adminfields (id, fieldlink, fieldrus) VALUES (13, 'password', 'Пароль');
INSERT INTO public.adminfields (id, fieldlink, fieldrus) VALUES (14, 'salary', 'Зарплата');
INSERT INTO public.adminfields (id, fieldlink, fieldrus) VALUES (15, 'income', 'Иной доход');