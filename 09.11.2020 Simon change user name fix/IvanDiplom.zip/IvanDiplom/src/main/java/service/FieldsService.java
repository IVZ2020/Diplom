package service;

import dao.FieldsDao;
import entity.Fields;

import java.lang.reflect.Field;
import java.util.List;

public class FieldsService {

    FieldsDao fieldsDao = new FieldsDao();

//    public void deleteAllFromAdminFieldsTable() {
//        fieldsDao.deleteAllFromAdminFieldsTable();
//    }
}
