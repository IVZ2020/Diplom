package service;

public class Writer {

    public void writer(String string) {
        System.out.println(string);
    }
}
