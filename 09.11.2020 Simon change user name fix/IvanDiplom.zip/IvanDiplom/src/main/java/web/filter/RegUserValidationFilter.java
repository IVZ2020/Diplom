package web.filter;

import dao.RegExDao;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter(servletNames = "RegServlet")
public class RegUserValidationFilter extends HttpFilter {

    @Override
    protected void doFilter(HttpServletRequest req, HttpServletResponse res, FilterChain chain) throws IOException, ServletException {

        if (req.getMethod().equals("POST")) {
            String userName = req.getParameter("userName");
            String userLastName = req.getParameter("userLastName");
            String userLogin = req.getParameter("userLogin");
            String userPassword = req.getParameter("userPassword");

            boolean nameIsValid = false;
            boolean lastNameIsValid = false;
            boolean loginIsValid = false;

            if (RegExDao.checkNameString(userName)) {
                nameIsValid = true;
            }

            if (RegExDao.checkLastNameString(userLastName)) {
                lastNameIsValid = true;
            }

            if (RegExDao.checkLoginString(userLogin)) {
                loginIsValid = true;
            }


            if (nameIsValid && lastNameIsValid && loginIsValid){
                chain.doFilter(req, res);
            } else {
                res.sendError(404, "Invalidate fields");
            }
        } else {
            chain.doFilter(req, res);
        }

    }
}
