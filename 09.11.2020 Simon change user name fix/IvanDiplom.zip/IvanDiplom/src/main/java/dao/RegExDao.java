package dao;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExDao {
    private static final String LOGIN_CHECK = "^[a-zA-Z0-9_-]+$";
    private static final String NAME_CHECK = "^[a-zA-Z]+$";
    private static final String LASTNAME_CHECK = "^[a-zA-Z-]+$";
    private static final String EMAIL_CHECK = "^[a-zA-Z0-9_-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$";

    public static boolean checkLoginString (String login) {
        Pattern pattern = Pattern.compile(LOGIN_CHECK);
        Matcher matcher = pattern.matcher(login);
        return matcher.matches();
    }

    public static boolean checkNameString (String name) {
        Pattern pattern = Pattern.compile(NAME_CHECK);
        Matcher matcher = pattern.matcher(name);
        return matcher.matches();
    }

    public static boolean checkLastNameString (String lastName) {
        Pattern pattern = Pattern.compile(LASTNAME_CHECK);
        Matcher matcher = pattern.matcher(lastName);
        return matcher.matches();
    }

    public static boolean checkEmailString (String eMail) {
        Pattern pattern = Pattern.compile(EMAIL_CHECK);
        Matcher matcher = pattern.matcher(eMail);
        return matcher.matches();
    }

}
