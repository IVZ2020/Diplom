package entity;

import java.util.Comparator;

public class ComporatorMenu implements Comparator<Menu> {

    @Override
    public int compare(Menu menu, Menu t1) {
        return 0;
    }


}
