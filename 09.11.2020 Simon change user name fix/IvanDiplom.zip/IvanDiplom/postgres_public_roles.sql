INSERT INTO public.roles (role, id) VALUES ('user', 1);
INSERT INTO public.roles (role, id) VALUES ('admin', 2);
INSERT INTO public.roles (role, id) VALUES ('moderator', 3);