INSERT INTO public.mainmenuwithauth (id, menulink, menurus) VALUES (1, 'help', 'Помощь');
INSERT INTO public.mainmenuwithauth (id, menulink, menurus) VALUES (2, 'logoutServlet', 'Выход');